package com.example.hongik_ce.myevent1;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu; import android.view.View; import android.widget.Button; import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {

    // Listener를 각각 구현할 경우에는 implements 제거해야 함

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //--- find both the buttons---
        Button sButton = (Button) findViewById(R.id.button_s);
        Button lButton = (Button) findViewById(R.id.button_l);

        // -- register click event with first button ---
        sButton.setOnClickListener(this);
        // -- register click event with second button ---
        lButton.setOnClickListener(this);
    }

    //--- Implement the OnClickListener callback
    public void onClick(View v) {
        if(v.getId() == R.id.button_s) {
            // --- find the text view --
            TextView txtView = (TextView) findViewById(R.id.text_id);
            // -- change text size --
            txtView.setTextSize(14);
            return;
        }
        if(v.getId() == R.id.button_l) {
            // --- find the text view --
            TextView txtView = (TextView) findViewById(R.id.text_id);
            // -- change text size --
            txtView.setTextSize(24);
            return;
        }
    }


/*
        // -- register click event with first button ---
        sButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // --- find the text view --
                TextView txtView = (TextView) findViewById(R.id.text_id);
                // -- change text size --
                txtView.setTextSize(14);
            }
        });

        // -- register click event with second button ---
        lButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // --- find the text view --
                TextView txtView = (TextView) findViewById(R.id.text_id);
                // -- change text size --
                txtView.setTextSize(24);
            }
        });
    }
   */
}
