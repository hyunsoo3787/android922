package com.example.hongik_ce.ex3broadcastreceiver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
     // broadcast a custom intent
     public void broadcastIntent(View view) {
            Intent intent = new Intent();
            intent.setAction("com.example.hongik_ce.CUSTOM_INTENT"); //com.tutorialspoint.com.CUSTOM_INTENT 와 비교
            sendBroadcast(intent);
     }
}
