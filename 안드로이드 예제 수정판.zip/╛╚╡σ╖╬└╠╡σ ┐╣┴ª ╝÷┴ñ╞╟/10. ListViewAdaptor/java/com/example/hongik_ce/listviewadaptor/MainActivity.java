package com.example.hongik_ce.listviewadaptor;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

    // Array of strings...
    String[] countryArray = {"대한민국", "미국", "중국", "이웃나라"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.activity_listview, countryArray);
        ListView listView = (ListView) findViewById(R.id.country_list); listView.setAdapter(adapter);
    }
}
